mfpConfigs['ResumeCancel'] = true;
mfp.extend.event('init',
	function(obj){
		obj.setAttribute('data-exc',1);
	}
);