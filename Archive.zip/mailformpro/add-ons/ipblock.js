mfpLang['WarningIPBlock'] = 'ご利用のIPアドレスは現在送信が制限されています。時間をおいてから再度ご送信ください。';
