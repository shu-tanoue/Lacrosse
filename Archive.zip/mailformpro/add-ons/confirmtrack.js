mfp.extend.event('confirm',
	function(){
		// 確認画面が表示された場合の処理
	}
);
mfp.extend.event('cancel',
	function(){
		// 確認画面がキャンセルされた場合の処理
	}
);