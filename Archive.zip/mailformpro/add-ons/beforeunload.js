mfp.extend.event('startup',
	function(){
		mfp.beforeunload = true;
	}
);
