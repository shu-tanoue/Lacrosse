jQuery(document).ready(function($) {
  $(".boxin2").counterUp({
    delay: 10,
    time: 1000
  });
});
