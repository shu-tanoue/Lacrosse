let checkStyle = document.getElementsByClassName('carousel-item active');
 
console.log(checkStyle)
